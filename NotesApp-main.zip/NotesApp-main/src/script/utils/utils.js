const Utils = {
  showElement(element) {
    element.hidden = false;
  },
  hideElement(element) {
    element.hidden = true;
  },
};

export default Utils;
